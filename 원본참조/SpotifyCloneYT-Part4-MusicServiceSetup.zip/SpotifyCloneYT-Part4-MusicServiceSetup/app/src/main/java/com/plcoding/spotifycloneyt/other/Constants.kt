package com.plcoding.spotifycloneyt.other

object Constants {

    const val SONG_COLLECTION = "songs"
}