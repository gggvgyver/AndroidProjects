# Balckjack Android Game

A classical Android blakcjack game, developed with Kotlin.

Funcgtion and feature
-----------------------
1. Mange accunt with Firebase Auth and data information stored in Firebase Storage.

2. Have a intro page after log in， to show how to control by guesture.

    -Swiping right allows the Player to hit.
    
    -Double tapping allows the Player to stand.
    
3. Game results is stored in database and there is a online leaderboard ranged all users based on win rate.

4. Cards being dealt are animated, and all cards are visible.

5. You can bet with free coins. (Not perfect this part.)
