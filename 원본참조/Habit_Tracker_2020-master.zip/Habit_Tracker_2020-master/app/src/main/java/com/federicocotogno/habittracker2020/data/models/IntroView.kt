package com.federicocotogno.habittracker2020.data.models

data class IntroView(val description: String, val image: Int) {
}